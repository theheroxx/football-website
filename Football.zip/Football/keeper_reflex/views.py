from django.shortcuts import render

def keeper_reflex(request):
    return render(request, 'keeper_reflex/keeper_reflex.html')
