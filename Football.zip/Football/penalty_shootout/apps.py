from django.apps import AppConfig


class PenaltyShootoutConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'penalty_shootout'
