from django.apps import AppConfig


class FreeKickChallengeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'free_kick_challenge'
